﻿using OpenQA.Selenium;

namespace OGS.Framework.Model.Obejct.Repository
{

    public class ModelObject
    {
        /// <summary>
        /// O metodo recupera um objeto da user interface do navegador, sendo este objeto um BY.
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        public static By ElementLocator(string locatorType, string locator)
        {
            By by; 
            switch (locatorType.ToUpper())
            {
                case "ID":
                    by = By.Id(locator);
                    break;
                case "NAME":
                    by = By.Name(locator);
                    break;
                case "CLASSNAME":
                    by = By.ClassName(locator);
                    break;
                case "XPATH":
                    by = By.XPath(locator);
                    break;
                case "CSS":
                    by = By.CssSelector(locator);
                    break;
                case "LINKTEXT":
                    by = By.LinkText(locator);
                    break;
                case "PARTIALLINKTEXT":
                    by = By.PartialLinkText(locator);
                    break;
                case "TAGNAME":
                    by = By.TagName(locator);
                    break;
                default:
                    by = null;
                    break;
            }
            return by;
        }
    }
}
