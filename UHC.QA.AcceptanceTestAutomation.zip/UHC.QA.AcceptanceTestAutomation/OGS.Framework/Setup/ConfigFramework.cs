﻿using System;
using System.Collections.Generic;
using System.Drawing;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;

namespace OGS.Framework.Setup
{
    public class ConfigFramework
    {
        public static Actions actions;
        public static readonly IDictionary<string, IWebDriver> Browser = new Dictionary<string, IWebDriver>();

        /// <summary>
        /// O metodo incializa o navegador já com a Url informada, porem é necessário informar os parametros no arquivo App.Config
        ///  - Parametros: _browser, _ambiente
        ///  - _browser = (Chrome, IE ou Firefox). Tipo: String
        ///  - _ambiente = informar a Url da aplicação. Tipo: String
        /// </summary>
        /// <returns>Retorna o browser aberto e operado na aplicação escolhida</returns>
        public IWebDriver StartBrowser(IWebDriver driver,string browser, string url)
        {
            try
            {
                driver = InitBrowser(driver, browser);
                LoadApplication(driver, url);
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro ao startar o Browser: " + e.ToString());
            }
            return driver;
        }

        /// <summary>
        /// O metodo incializa o navegador já com a Url informada, sem a a necessidade da passage, de parâmetros no arquivo App.Config
        /// </summary>
        /// <returns>Retorna o browser aberto e operado na aplicação escolhida</returns>
        public IWebDriver StartBrowser(IWebDriver driver)
        {
            try
            {
                driver = InitBrowser(driver, AppConfig.ReadSetting("_browser"));
                LoadApplication(driver, AppConfig.ReadSetting("_ambiente"));
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro ao startar o Browser: " + e.ToString());
            }
            return driver;
        }

        /// <summary>
        /// O metodo finaliza os cookies e fecha o navegadore.
        /// </summary>
        public static void EndBrowser(IWebDriver driver)
        {
            if (driver != null)
            {
                DeleteCookies(driver);
                CloseBrowser(driver);
            }
        }

        public static string GetPathProject()
        {
            string path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            string actualPath = path.Substring(0, path.LastIndexOf("bin"));
            string projectPath = new Uri(actualPath).LocalPath;

            return projectPath;
        }

        /// <summary>
        /// O metodo incializa o navegador já com a Url informada, porem é necessário informar os parametros no arquivo App.Config
        ///  ou passar o parametro com o nome do navegador escolhido
        ///  - Parametros: - browserName = (Chrome, IE ou Firefox).
        /// </summary>
        public IWebDriver InitBrowser(IWebDriver driver, String browserName)
        {
            Browser.Clear();
            switch (browserName)
            {
                case "CHROME":
                    ChromeOptions options = new ChromeOptions();
                    options.AddArgument("--test-type");
                    options.AddArgument("--start-maximized");
                    options.AddArgument("--disable-extensions");
                    options.AddAdditionalCapability("useAutomationExtension", false);
                    driver = new ChromeDriver(options);
                    break;
                case "FIREFOX":
                    driver = new FirefoxDriver();
                    driver.Manage().Window.Maximize();
                    break;
                case "IE":
                    driver = new InternetExplorerDriver();
                    driver.Manage().Window.Maximize();
                    break;
                default:
                    Console.WriteLine("Nenhum Browser foi iniciado.");
                    break;
            }
            actions = new Actions(driver);
            return driver;
        }

        /// <summary>
        /// O metodo incializa o navegador já com a Url informada, porem é necessário informar os parametros no arquivo App.Config
        ///  ou passar o parametro com o nome do navegador escolhido
        ///  - Parametros: - browserName = (Chrome, IE ou Firefox).
        /// </summary>
        public IWebDriver InitBrowser(IWebDriver driver, String browserName, string[] extension)
        {
            Browser.Clear();
            switch (browserName)
            {
                case "CHROME":
                    //Em analise para executar teste em navegador headless---------------------
                    //ChromeOptions option = new ChromeOptions();
                    //option.AddArgument("--headless");
                    //option.AddArgument("--disable-gpu");
                    //driver = new ChromeDriver(option);
                    //--------------------------------------------------------------------------
                    ChromeOptions options = new ChromeOptions();
                    options.AddArgument("--test-type");
                    options.AddArgument("--start-maximized");
                    options.AddAdditionalCapability("useAutomationExtension", false);
                    if (extension != null)
                    {
                        foreach (string ex in extension)
                        {
                            options.AddExtension(new Uri(GetPathProject() + ex).LocalPath);
                        }
                    }
                    driver = new ChromeDriver(options);
                    break;
                case "FIREFOX":
                    driver = new FirefoxDriver();
                    driver.Manage().Window.Maximize();
                    break;
                case "IE":
                    driver = new InternetExplorerDriver();
                    driver.Manage().Window.Maximize();
                    break;
                default:
                    Console.WriteLine("Nenhum Browser foi iniciado.");
                    break;
            }
            
            actions = new Actions(driver);
            return driver;
        }

        /// <summary>
        /// An expectation for checking that an element is present on the DOM of a
        /// page. This does not necessarily mean that the element is visible or clickable.
        /// </summary>
        /// <param name="driver">IWebDriver object that is not instanced</param>
        /// <param name="browserName">Which will be the used browser? CHROME, FIREFOX or IE</param>
        /// <param name="isIncognito">Boolean that indicates if the browser should be started in incognito/private mode</param>
        public IWebDriver InitBrowser(IWebDriver driver, String browserName, bool isIncognito)
        {
            Browser.Clear();
            switch (browserName.ToUpper())
            {
                case "CHROME":
                    ChromeOptions chromeOptions = new ChromeOptions();
                    chromeOptions.AddArgument("--test-type");
                    chromeOptions.AddArgument("--disable-extensions");
                    chromeOptions.AddArgument("--start-maximized");
                    if (isIncognito)
                    {
                        chromeOptions.AddArgument("incognito");
                    }
                    driver = new ChromeDriver(chromeOptions);
                    break;
                case "FIREFOX":
                    FirefoxOptions firefoxOptions = new FirefoxOptions();
                    if (isIncognito)
                    {
                        firefoxOptions.AddArgument("-private");
                    }
                    driver = new FirefoxDriver(firefoxOptions);
                    driver.Manage().Window.Maximize();
                    break;
                case "IE":
                    InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                    if (isIncognito)
                    {
                        ieOptions.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                        ieOptions.IgnoreZoomLevel = true;
                        ieOptions.InitialBrowserUrl = "about:InPrivate";
                        ieOptions.EnsureCleanSession = true;
                        ieOptions.BrowserCommandLineArguments = "-private";
                    }
                    driver = new InternetExplorerDriver(ieOptions);
                    driver.Manage().Window.Maximize();
                    break;
                default:
                    Console.WriteLine("Nenhum Browser foi iniciado.");
                    break;
            }
            actions = new Actions(driver);
            return driver;
        }

        /// <summary>
        /// O metodo informa ao navegador um URL para ele poder acessar a aplciação especifica
        ///  ou passar o parametro com o nome do navegador escolhido
        ///  - Parametros: - url = "https://www.google.com"
        /// </summary>
        public static void LoadApplication(IWebDriver driver, string url)
        {
            if (driver != null)
            {
                driver.Url = url;
                int timeOutImplicit = Convert.ToInt16(AppConfig.ReadSetting("_implicitWaitSecond"));
                driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(timeOutImplicit);
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(timeOutImplicit);
                Console.WriteLine(String.Format("Aplicação foi iniciada com a Url: [{0}].", url));
            }
        }

        /// <summary>
        /// O metodo deleta os cookies de um navegador ativo na sessão
        /// </summary>
        public static void DeleteCookies(IWebDriver driver)
        {
            driver.Manage().Cookies.DeleteAllCookies();
            Console.WriteLine("Cookies deletados.");
        }

        /// <summary>
        /// O metodo fecha o Browser aberto pelo processo.
        /// </summary>
        public static void CloseBrowser(IWebDriver driver)
        {
            if (driver != null)
            {
                driver.Quit();
                Console.WriteLine("Navegação encerrada.");
            }
            
        }

        
    }
}
