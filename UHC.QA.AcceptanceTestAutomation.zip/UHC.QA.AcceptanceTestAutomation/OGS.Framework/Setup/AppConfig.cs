﻿using System;
using System.Collections.Generic;
using System.Configuration;

namespace OGS.Framework.Setup
{
    public class AppConfig
    {
        /// <summary>
        /// O metodo retorna uma lista com os valores informados no arquivo App.Config sobre a tag xml appSettings com o parametro 
        /// inciado com underline '_'.
        /// </summary>
        public List<string> ReadAllSettings()
        {

            List<string> listValue = new List<string>();

            try
            {
                var appSettings = ConfigurationManager.AppSettings;

                if (appSettings.Count == 0)
                {
                    Console.WriteLine("AppSettings is empty.");

                }
                else
                {
                    foreach (var key in appSettings.AllKeys)
                    {
                        if (key.StartsWith("_"))
                        {
                            listValue.Add(ReadSetting(key));
                            Console.WriteLine("Key: {0} Value: {1}", key, appSettings[key]);
                        }

                    }

                }

            }
            catch (ConfigurationErrorsException)
            {
                Console.WriteLine("Error reading app settings");

            }
            return listValue;
        }
        /// <summary>
        /// O metodo retorna o valor de um arquivo do tipo App.Config sobre a tag xml appSettings.
        /// </summary>
        /// <param name="key"> Passa o valor que represeta a chave do identificador do node do AppConfig</param>
        /// <returns>Retorna valor correspondente a Key informada - retorna uma string</returns>
        public static string ReadSetting(string key)
        {
            string result;
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                result = appSettings[key] ?? "Chave não encontrada!";
                return result;

            }
            catch (ConfigurationErrorsException)
            {
                Console.WriteLine("Arquivo App.config, não encontrado");
                return "";
            }
            
        }
    }
}