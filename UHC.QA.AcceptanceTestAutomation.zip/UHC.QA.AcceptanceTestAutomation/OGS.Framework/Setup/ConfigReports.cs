﻿using System;
using AventStack.ExtentReports;
using OpenQA.Selenium;
using System.IO;
using OGS.Framework.Utility;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AventStack.ExtentReports.Reporter;

namespace OGS.Framework.Setup
{
    public class ConfigReports : ConfigFramework
    {
        //public static IWebDriver driver;
        public static ExtentReports extent = new ExtentReports();
        public static ExtentTest test;
        public static Status logstatus;
        public static string logReport;
        public static bool gerarReport = false;


        /// <summary>
        /// O metodo incializa o recurso de geração de envidências chamado ExtentReport dos Testes Executados.
        /// </summary>
        public static void InitLog(string FeatureName)
        {
            string extentxReporter;
            string pathReports;

            gerarReport = true;


            string path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            string actualPath = path.Substring(0, path.LastIndexOf("bin"));
            string projectPath = new Uri(actualPath).LocalPath;

            //Capturar hora e Capturar data
            string hora = DateTime.Now.ToShortTimeString();
            string data = DateTime.Now.ToShortDateString();
            string dataHora = data.Replace("/", "") + "_" + hora.Replace(":", "");

            if (AppConfig.ReadSetting("_extentpath").Contains("Chave não encontrada") || AppConfig.ReadSetting("_extentpath") == "")
            {
                pathReports = projectPath + "Reports\\";
                extentxReporter = pathReports + FeatureName + "_" + dataHora + ".html";
            }
            else
            {
                pathReports = AppConfig.ReadSetting("_extentpath");
                extentxReporter = pathReports + FeatureName + "_" + dataHora + ".html";
            }

            extentxReporter = new Uri(extentxReporter).LocalPath;
            pathReports = new Uri(pathReports).LocalPath;

            CreateDirectory(pathReports);

            string filePath = projectPath + "extent-config.xml";

            ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(extentxReporter);
            htmlReporter.Configuration().GetConfiguration();

            extent = new ExtentReports();
            extent.AddSystemInfo("Usuario", Environment.UserName);
            extent.AddSystemInfo("Dominio de Rede", Environment.UserDomainName);
            extent.AddSystemInfo("Nome da máquina", Environment.MachineName);
            extent.AddSystemInfo("Sistema Operacional", Environment.OSVersion.ToString());

            extent.AnalysisStrategy.ToString();
            extent.AttachReporter(htmlReporter);
            htmlReporter.LoadConfig(filePath);
        }

        /// <summary>
        /// O metodo que adiciona o nome do caso de teste conforme nome definido na camada Test.UI.
        /// </summary>
        public static void TestCaseName(TestContext context, string name = "")
        {
            if (name == "")
            {
                test = extent.CreateTest(context.TestName);
            }
            else
            {
                test = extent.CreateTest(name);
            }
            //Reinicia a variavel com status do caso de teste
            logstatus = Status.Pass;
        }

        /// <summary>
        /// O metodo que captura o screenshot da ação executada no teste.
        /// </summary>
        public static string ScreenShot(IWebDriver driver)
        {
            string localPath;
            string folder;
            Screenshot screenshot;

            Verification.Wait(2);
            if (driver != null)
            {
                ITakesScreenshot ts = (ITakesScreenshot)driver;
                screenshot = ts.GetScreenshot();

                string path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;

                if (AppConfig.ReadSetting("_extentpath").Contains("Chave não encontrada") || AppConfig.ReadSetting("_extentpath") == "")
                {
                    folder = path.Substring(0, path.LastIndexOf("bin")) + "Reports\\imgScreenShot/";
                }
                else
                {
                    folder = AppConfig.ReadSetting("_extentpath") + "imgScreenShot/";
                }

                string folderPath = new Uri(folder).LocalPath;

                string img_name = "ScreenShot_" + DateTime.Now.ToString("hhmmsstt") + ".png";
                localPath = folderPath + img_name;

                CreateImage(screenshot, folderPath, localPath);

                return localPath;
            }

            return "";

        }

        public static Boolean CreateDirectory(string folderPath)
        {
            try
            {
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return false;
            }

            return true;

        }

        public static void CreateImage(Screenshot screenshot, string folderPath, string localPath)
        {
            if (CreateDirectory(folderPath))
            {
                screenshot.SaveAsFile(localPath, ScreenshotImageFormat.Png);
            }
        }

        /// <summary>
        /// O metodo gera o log com os status de cada ação executada no test.
        /// </summary>
        public static void GenerateLog(TestContext context, IWebDriver driver)
        {
            var status = context.CurrentTestOutcome;
            //var message = string.IsNullOrEmpty(context.)
            //    ? ""
            //    : string.Format("<pre>{0}</pre>", context.Result.Message);

            switch (status)
            {
                case UnitTestOutcome.Passed:
                    logstatus = Status.Pass;
                    break;
                case UnitTestOutcome.Failed:
                    logstatus = Status.Fail;
                    test.Log(logstatus, String.Format(":::. Resultado Final .:::") /*+ "<br/>" + message + "<br/>"*/ + logReport + "<br/>" + String.Format(":::. Resultado Final .:::") + "<br/>").AddScreenCaptureFromPath(ScreenShot(driver));
                    EndBrowser(driver);
                    break;
                case UnitTestOutcome.Inconclusive:
                    logstatus = Status.Warning;
                    break;
                default:
                    logstatus = Status.Info;
                    break;
            }
        }

        /// <summary>
        /// O metodo gera o log com os status de cada ação executada no test.
        /// </summary>
        public static void GenerateLog(TestContext context)
        {
            var status = context.CurrentTestOutcome;
            //var message = string.IsNullOrEmpty(TestContext.CurrentContext.Result.Message)
            //    ? ""
            //    : string.Format("<pre>{0}</pre>", TestContext.CurrentContext.Result.Message);

            switch (status)
            {
                case UnitTestOutcome.Passed:
                    logstatus = Status.Pass;
                    break;
                case UnitTestOutcome.Failed:
                    logstatus = Status.Fail;
                    test.Log(logstatus, String.Format(":::. Resultado Final .:::") /*+ "<br/>" + message + "<br/>"*/ + logReport + "<br/>" + String.Format(":::. Resultado Final .:::") + "<br/>");
                    break;
                case UnitTestOutcome.Inconclusive:
                    logstatus = Status.Warning;
                    break;
                default:
                    logstatus = Status.Info;
                    break;
            }
        }

        /// <summary>
        /// O metodo fecha a geração do log ExtentReport aberto pelo processo.
        /// </summary>
        public static void CloseLog()
        {
            extent.Flush();
        }

        /// <summary>
        /// O mettodo gera report por step do caso de teste.
        /// </summary>
        public static void ReportStep(IWebDriver driver, string logMessage)
        {
            if (gerarReport)
            {
                test.Log(logstatus, string.Format(logMessage), MediaEntityBuilder.CreateScreenCaptureFromPath(ScreenShot(driver)).Build());
            }
            Console.WriteLine(string.Format(logMessage));
        }

        /// <summary>
        /// O mettodo gera report por step do caso de teste.
        /// </summary>
        public static void ReportStep(string logMessage)
        {
            if (gerarReport)
            {
                test.Log(logstatus, logMessage);
            }
            Console.WriteLine(logMessage);
        }
    }
}
