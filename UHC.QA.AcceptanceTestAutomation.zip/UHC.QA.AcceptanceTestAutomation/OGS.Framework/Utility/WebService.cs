﻿using System.IO;
using System.Net;
using System;
using System.Web;
using System.Text;
using OGS.Framework.Setup;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OGS.Framework.Utility
{
    public class WebService : ConfigReports
    {
        #region Atributos

        private string baseUri { get; set; }
        public CookieContainer cookieContainer { get; set; }

        public string strServer { get; set; }
        public string objResponse { get; set; }

        #endregion

        #region Metodos de Suporte
        /// <summary>
        /// Constructor for receive url from server (baseUri)
        /// </summary>
        /// <param name="_baseUri"> address server as baseUri for exampla: http://api-vendasonline-dental3.qa.amil.com.br </param>
        /// <param name="value"> represent the value of the locatorType</param>
        public WebService(string _baseUri)
        {
            //baseUri = _baseUri.ToLower();
            baseUri = _baseUri;
        }

        /// <summary>
        /// Create object for receive cookie or token with credential of the session  
        /// </summary>
        /// <returns>The <see cref="cookieContainer"/> return value of the object with cookies session.</returns>
        public CookieContainer CreatecookieContainer()
        {
            if (cookieContainer == null)
            {
                cookieContainer = new CookieContainer();
            }
            return cookieContainer;
        }

        /// <summary>
        /// Replace Value for Url Enconde, to solver problem in request post or get with parameter in URL with special character  
        /// </summary>
        /// <param name="text"> Value content url path </param>
        /// <returns>The <see cref="text"/> return value correct to send request to web Service</returns>
        private static string ReplaceValueForUrlEncode(string text)
        {
            string comAcentos = "ÄÅÁÂÀÃäáâàãÉÊËÈéêëèÍÎÏÌíîïìÖÓÔÒÕöóôòõÜÚÛüúûùÇç";

            for (int i = 0; i < text.Length; ++i)
            {
                for (int j = 0; j < comAcentos.Length; j++)
                {
                    if (Equals(text[i].ToString(), comAcentos[j].ToString()))
                    {
                        text = text.Replace(comAcentos[j].ToString(), HttpUtility.UrlEncode(comAcentos[j].ToString()));
                    }
                }
            }

            return text;
        }

        /// <summary>
        /// Convert User and PassWord in Base 64 enconde, for basic authetication  
        /// </summary>
        /// <param name="plainText"> value content user and password in format "user:pass" </param>
        /// <param name="json"> value with json in format string </param>
        /// <returns>The <see cref="plainText"/> return value of the kind string content base64 coverted.</returns>
        private static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            ReportStep("<b>Metodo Base64Encode</b> <br/><br/>  Base64 encode gerado com sucesso!");
            return Convert.ToBase64String(plainTextBytes);
        }

        /// <summary>
        /// Get cookie for keep application live in the next web request  
        /// </summary>
        /// <param name="webRequest">object content webRequest </param>
        /// <param name="cookieName"> value in string content cookie Name </param>
        /// <returns>The <see cref="Cookie"/> return object with all the cookies </returns>
        public void GetCookie(HttpWebRequest webRequest, string cookieName)
        {

            string servidor;
            HttpWebResponse resposta = (HttpWebResponse)webRequest.GetResponse();
            Cookie cookie_formatado;
            try
            {
                webRequest.CookieContainer = new CookieContainer();
                string AuthCookies = resposta.Headers.ToString();

                Uri target = new Uri(baseUri);

                CreatecookieContainer();

                if (baseUri.IndexOf("http:") == 0)
                {
                    servidor = baseUri.Remove(0, 7);
                    if (servidor.Contains("/"))
                    {
                        servidor = servidor.Remove(servidor.IndexOf("/"));
                    }
                }
                else
                {
                    servidor = baseUri.Remove(0, 8);
                    if (servidor.Contains("/"))
                    {
                        servidor = servidor.Remove(servidor.IndexOf("/"));
                    }
                }

                string Cookie = AuthCookies.Substring(AuthCookies.IndexOf(cookieName) + cookieName.Length);
                Cookie = Cookie.Substring(0, Cookie.IndexOf(";"));
                webRequest.CookieContainer.Add(new Cookie(cookieName.Remove(cookieName.Length - 1, 1), Cookie) { Domain = target.Host });
                cookie_formatado = new Cookie(cookieName.Remove(cookieName.Length - 1, 1), Cookie, "/", servidor);
                cookieContainer.Add(cookie_formatado);

                ReportStep("<b>Metodo GetCookie</b> <br/><br/><b>Foi adicionado com sucesso o cookie: </b>" + cookieName + " <b>no cookieContainer.</b>");
            }
            catch (Exception e)
            {
                ReportStep("<b>Metodo GetCookie</b> <br/><br/> <b>Erro ao adicionar cookie no cookieContainer: </b>" + e.ToString());
                Assert.Fail("Metodo GetCookie \n Erro ao adicionar cookie no cookieContainer: " + e.ToString());
            }
        }

        #endregion

        #region Metodos GET

        /// <summary>
        /// Get Web Request with cookie session autheticate or without and validate status http and bory message
        /// </summary>
        /// <param name="pathUrl"> addres to complement address of the webservice, for exampla: "api/fale-conosco?tipoUsuario=Não Cliente&filtro.localidade=SP&filtro.assunto=duvida" </param>
        /// <param name="contentType"> optional value - kind of the content-type for exampla: json or xml or text</param>
        /// <param name="statusCodeHttp"> kind of the Response Code http for example: 200, 201, 302. if greatest than 400 is consider WebException </param>
        /// <param name="expectedValue"> value expected in body menssage of the kin array</param>
        /// <param name="coookieContainer"> optional object with the cookies and session values</param>
        public string GetHttpWebRequest(string pathUrl, string contentType, int statusCodeHttp, string[] expectedValue,string[,] headers, CookieContainer coookieContainer)
        {
            Stream streamDados;
            HttpWebResponse resposta;
            try
            {

                if (pathUrl != null)
                {
                    strServer = baseUri + "/" + ReplaceValueForUrlEncode(pathUrl);
                }
                else
                {
                    strServer = baseUri;
                }

                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(strServer);

                if (headers != null)
                {
                    for (int i = 0; i <= headers.GetUpperBound(0); i++)
                    {
                        webrequest.Headers.Add(headers[i, 0], headers[i, 1]);
                    }
                }

                webrequest.Method = "GET";

                if (contentType != null)
                {
                    webrequest.ContentType = "application/" + contentType;
                }

                else if (coookieContainer != null)
                {
                    webrequest.CookieContainer = coookieContainer;
                }

                resposta = (HttpWebResponse)webrequest.GetResponse();

                streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                objResponse = reader.ReadToEnd();

                if ((int)resposta.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo GetHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)resposta.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("\n Resposta gerada com sucesso \n O Valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso \n O Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }
                        
                    }
                }
                else
                {
                    Assert.Fail("Metodo GetHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)resposta.StatusCode + " \n log error:" + objResponse);
                }

                ReportStep("Resposta do servidor: \n\n" + objResponse);
                streamDados.Close();
                resposta.Close();
            }
            catch (WebException wex)
            {

                var errorResponse = (HttpWebResponse)wex.Response;

                var reader = new StreamReader(errorResponse.GetResponseStream());

                string objResponse = reader.ReadToEnd();

                if ((int)errorResponse.StatusCode == statusCodeHttp)
                {

                    ReportStep("Metodo GetHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)errorResponse.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("Resposta gerada com sucesso.\n O valor '" + value + "' foi encontrado!");
                            }
                            else
                            {

                                Assert.Fail("\n Resposta gerada com sucesso, porém o Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }

                    }
                }
                else
                {
                    Assert.Fail("Metodo GetHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)errorResponse.StatusCode + " \n log error:" + objResponse);
                }

                ReportStep("Response body: \n \n" + objResponse);

            }
            catch (Exception ex)
            {
                Assert.Fail("Metodo GetHttpWebRequest \n Erro ao Processar a requisição para o WebService. Log: " + ex.ToString());
            }

            return objResponse;

        }
        #endregion

        #region Metodos POST

        /// <summary>
        /// Post Web Request with basic autheticate server and validate status http and bory message
        /// </summary>
        /// <param name="pathUrl"> addres to complement address of the webservice, for exampla: "api/fale-conosco?tipoUsuario=Não Cliente&filtro.localidade=SP&filtro.assunto=duvida" </param>
        /// <param name="contentType"> kind of the content-type for exampla: json or xml or text</param>
        /// <param name="statusCodeHttp"> kind of the Response Code http for example: 200, 201, 302. if greatest than 400 is consider WebException </param>
        /// <param name="expectedValue"> value expected in body menssage</param>
        /// <param name="user"> variable optional, pass variable with user for authentic server</param>
        /// <param name="senha"> variable optional, pass variable with password for authentic server</param>
        /// <returns>The <see cref="HttpWebRequest"/> return value of the object with HttpWebRequest.</returns>
        public HttpWebRequest PostHttpWebRequest(string pathUrl, string contentType, int statusCodeHttp, string[] expectedValue, string[,] headers, string user = "userDefault", string senha = "senhaDefault")
        {
            HttpWebRequest webrequest = null;
            try
            {
                if (pathUrl != null)
                {
                    strServer = baseUri + "/" + ReplaceValueForUrlEncode(pathUrl);
                }
                else
                {
                    strServer = baseUri;
                }

                webrequest = (HttpWebRequest)WebRequest.Create(strServer);

                if (headers != null)
                {
                    for (int i = 0; i <= headers.GetUpperBound(0); i++)
                    {
                        webrequest.Headers.Add(headers[i, 0], headers[i, 1]);
                    }

                }

                webrequest.Method = "POST";

                if (contentType != null)
                {
                    webrequest.ContentType = "application/" + contentType;
                }
                if (user != "userDefault" && senha != "senhaDefault")
                {
                    webrequest.Headers[HttpRequestHeader.Authorization] = "Basic " + Base64Encode(user + ":" + senha);
                }

                HttpWebResponse resposta = (HttpWebResponse)webrequest.GetResponse();
                Stream streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                objResponse = reader.ReadToEnd();

                if ((int)resposta.StatusCode == statusCodeHttp)
                {

                    ReportStep("Metodo PostHttpWebReques<  \n \n Request: " + strServer + " \n Status Code: " + (int)resposta.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("\n Resposta gerada com sucesso \n O Valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso \n O Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }
                    }
                }
                else
                {
                    Assert.Fail("Metodo PostHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)resposta.StatusCode + " \n log error:" + objResponse);
                }

                ReportStep("Response body: \n \n" + objResponse);
                streamDados.Close();
                resposta.Close();

            }
            catch (WebException wex)
            {

                var errorResponse = (HttpWebResponse)wex.Response;

                var reader = new StreamReader(errorResponse.GetResponseStream());

                string objResponse = reader.ReadToEnd();

                if ((int)errorResponse.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PostHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)errorResponse.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("Resposta gerada com sucesso.\n O valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso, porém o Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }

                    }
                }
                else
                {
                    Assert.Fail("Metodo PostHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)errorResponse.StatusCode + " \n log error:" + objResponse);   
                }

                ReportStep("Response body: \n \n" + objResponse);

            }
            catch (Exception ex)
            {
                Assert.Fail("Metodo GetHttpWebRequest \n Erro ao Processar a requisição para o WebService. Log: " + ex.ToString());
            }

            return webrequest;

        }

        /// <summary>
        /// Post Web Request and validate status http and bory message without authetication 
        /// </summary>
        /// <param name="pathUrl"> addres to complement address of the webservice, for exampla: "api/fale-conosco?tipoUsuario=Não Cliente&filtro.localidade=SP&filtro.assunto=duvida" </param>
        /// <param name="contentType"> kind of the content-type for exampla: json or xml or text</param>
        /// <param name="statusCodeHttp"> kind of the Response Code http for example: 200, 201, 302. if greatest than 400 is consider WebException </param>
        /// <param name="expectedValue"> value expected in body menssage</param>
        /// <returns>The <see cref="objResponse"/> return value of the kind string content body mensage of the response.</returns>
        public string PostHttpWebRequest(string pathUrl, string contentType, int statusCodeHttp, string[] expectedValue, string[,] headers)
        {
            HttpWebRequest webrequest = null;
            try
            {
                if (pathUrl != null)
                {
                    strServer = baseUri + "/" + ReplaceValueForUrlEncode(pathUrl);
                }
                else
                {
                    strServer = baseUri;
                }
                ASCIIEncoding encoder = new ASCIIEncoding();
                byte[] data = encoder.GetBytes(strServer);
                webrequest = (HttpWebRequest)WebRequest.Create(strServer);

                if (headers != null)
                {
                    for (int i = 0; i <= headers.GetUpperBound(0); i++)
                    {
                        webrequest.Headers.Add(headers[i, 0], headers[i, 1]);
                    }

                }

                webrequest.Method = "POST";
                if (contentType != null)
                {
                    webrequest.ContentType = "application/" + contentType;
                }
                webrequest.ContentLength = data.Length;
                webrequest.GetRequestStream().Write(data, 0, data.Length);

                HttpWebResponse resposta = (HttpWebResponse)webrequest.GetResponse();
                Stream streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                objResponse = reader.ReadToEnd();


                if ((int)resposta.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PostHttpWebReques<  \n \n Request: " + strServer + " \n Status Code: " + (int)resposta.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("\n Resposta gerada com sucesso \n O Valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso \n O Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }
                    }
                }
                else
                {
                    Assert.Fail("Metodo PostHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)resposta.StatusCode + " \n log error:" + objResponse);
                }
                ReportStep("Response body: \n \n" + objResponse);
                streamDados.Close();
                resposta.Close();
            }
            catch (WebException wex)
            {

                var errorResponse = (HttpWebResponse)wex.Response;

                var reader = new StreamReader(errorResponse.GetResponseStream());

                string objResponse = reader.ReadToEnd();

                if ((int)errorResponse.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PostHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)errorResponse.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("Resposta gerada com sucesso.\n O valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso, porém o Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }

                    }
                }
                else
                {
                    Assert.Fail("Metodo PostHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)errorResponse.StatusCode + " \n log error:" + objResponse);
                }
                ReportStep("Response body: \n \n" + objResponse);

            }
            catch (Exception ex)
            {
                Assert.Fail("Metodo GetHttpWebRequest \n Erro ao Processar a requisição para o WebService. Log: " + ex.ToString());
            }

            return objResponse;
        }

        /// <summary>
        /// Post Web Request and send body json and validate status http and bory message 
        /// </summary>
        /// <param name="pathUrl"> addres to complement address of the webservice, for exampla: "api/fale-conosco?tipoUsuario=Não Cliente&filtro.localidade=SP&filtro.assunto=duvida" </param>
        /// <param name="contentType"> kind of the content-type for exampla: json or xml or text</param>
        /// <param name="statusCodeHttp"> kind of the Response Code http for example: 200, 201, 302. if greatest than 400 is consider WebException </param>
        /// <param name="expectedValue"> value expected in body menssage</param>
        /// <param name="json"> value with json in format string </param>
        /// <returns>The <see cref="objResponse"/> return value of the kind string content body mensage of the response.</returns>
        public string PostHttpWebRequest(string pathUrl, string contentType, int statusCodeHttp, string[] expectedValue, string[,] headers, string json)
        {
            HttpWebRequest webrequest = null;
            try
            {
                if (pathUrl != null)
                {
                    strServer = baseUri + "/" + ReplaceValueForUrlEncode(pathUrl);
                }
                else
                {
                    strServer = baseUri;
                }
                webrequest = (HttpWebRequest)WebRequest.Create(strServer);

                if (headers != null)
                {
                    for (int i = 0; i <= headers.GetUpperBound(0); i++)
                    {
                        webrequest.Headers.Add(headers[i, 0], headers[i, 1]);
                    }

                }

                webrequest.Method = "POST";
                if (contentType != null)
                {
                    webrequest.ContentType = "application/" + contentType;
                }


                using (var streamWriter = new StreamWriter(webrequest.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                HttpWebResponse resposta = (HttpWebResponse)webrequest.GetResponse();
                Stream streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                objResponse = reader.ReadToEnd();

                if ((int)resposta.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PostHttpWebReques<  \n \n Request: " + strServer + " \n Status Code: " + (int)resposta.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("\n Resposta gerada com sucesso \n O Valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso \n O Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }
                    }
                }
                else
                {
                    Assert.Fail("Metodo PostHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)resposta.StatusCode + " \n log error:" + objResponse);
                }

                ReportStep("Response body: \n \n" + objResponse);
                streamDados.Close();
                resposta.Close();
            }
            catch (WebException wex)
            {

                var errorResponse = (HttpWebResponse)wex.Response;

                var reader = new StreamReader(errorResponse.GetResponseStream());

                string objResponse = reader.ReadToEnd();

                if ((int)errorResponse.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PostHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)errorResponse.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("Resposta gerada com sucesso.\n O valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso, porém o Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }

                    }
                }
                else
                {
                    Assert.Fail("Metodo PostHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)errorResponse.StatusCode + " \n log error:" + objResponse);
                }
                ReportStep("Response body: \n \n" + objResponse);
            }
            catch (Exception ex)
            {
                Assert.Fail("Metodo GetHttpWebRequest \n Erro ao Processar a requisição para o WebService. Log: " + ex.ToString());
            }

            return objResponse;
        }

        #endregion

        #region Metodos DELETE

        /// <summary>
        /// Delete Web Request and validate status http and body message without authetication 
        /// </summary>
        /// <param name="pathUrl"> addres to complement address of the webservice, for exampla: "api/fale-conosco?tipoUsuario=Não Cliente&filtro.localidade=SP&filtro.assunto=duvida" </param>
        /// <param name="contentType"> kind of the content-type for exampla: json or xml or text</param>
        /// <param name="statusCodeHttp"> kind of the Response Code http for example: 200, 201, 302. if greatest than 400 is consider WebException </param>
        /// <param name="expectedValue"> value expected in body menssage</param>
        /// <returns>The <see cref="objResponse"/> return value of the kind string content body mensage of the response.</returns>
        public string DeleteHttpWebRequest(string pathUrl, string contentType, int statusCodeHttp, string[] expectedValue, string[,] headers)
        {
            HttpWebRequest webrequest = null;
            try
            {
                if (pathUrl != null)
                {
                    strServer = baseUri + "/" + ReplaceValueForUrlEncode(pathUrl);
                }
                else
                {
                    strServer = baseUri;
                }
                ASCIIEncoding encoder = new ASCIIEncoding();
                byte[] data = encoder.GetBytes(strServer);
                webrequest = (HttpWebRequest)WebRequest.Create(strServer);
                if (headers != null)
                {
                    for (int i = 0; i <= headers.GetUpperBound(0); i++)
                    {
                        webrequest.Headers.Add(headers[i, 0], headers[i, 1]);
                    }

                }
                webrequest.Method = "DELETE";
                if (contentType != null)
                {
                    webrequest.ContentType = "application/" + contentType;
                }
                webrequest.ContentLength = data.Length;
                webrequest.GetRequestStream().Write(data, 0, data.Length);

                HttpWebResponse resposta = (HttpWebResponse)webrequest.GetResponse();
                Stream streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                objResponse = reader.ReadToEnd();


                if ((int)resposta.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo DeleteHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)resposta.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("\n Resposta gerada com sucesso \n O Valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso \n O Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }
                    }
                }
                else
                {
                    Assert.Fail("Metodo DeleteHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)resposta.StatusCode + " \n log error:" + objResponse);
                }

                ReportStep("Response body: \n \n" + objResponse);
                streamDados.Close();
                resposta.Close();
            }
            catch (WebException wex)
            {

                var errorResponse = (HttpWebResponse)wex.Response;

                var reader = new StreamReader(errorResponse.GetResponseStream());

                string objResponse = reader.ReadToEnd();

                if ((int)errorResponse.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo DeleteHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)errorResponse.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("Resposta gerada com sucesso.\n O valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso, porém o Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }

                    }
                }
                else
                {
                    Assert.Fail("Metodo DeleteHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)errorResponse.StatusCode + " \n log error:" + objResponse);
                }

                ReportStep("Response body: \n \n" + objResponse);
            }
            catch (Exception ex)
            {
                Assert.Fail("Metodo DeleteHttpWebRequest \n Erro ao Processar a requisição para o WebService. Log: " + ex.ToString());
            }

            return objResponse;
        }

        #endregion

        #region Metodos PUT

        /// <summary>
        /// Post Web Request and send body json and validate status http and bory message 
        /// </summary>
        /// <param name="pathUrl"> addres to complement address of the webservice, for exampla: "api/fale-conosco?tipoUsuario=Não Cliente&filtro.localidade=SP&filtro.assunto=duvida" </param>
        /// <param name="contentType"> kind of the content-type for exampla: json or xml or text</param>
        /// <param name="statusCodeHttp"> kind of the Response Code http for example: 200, 201, 302. if greatest than 400 is consider WebException </param>
        /// <param name="expectedValue"> value expected in body menssage</param>
        /// <param name="json"> value with json in format string </param>
        /// <returns>The <see cref="objResponse"/> return value of the kind string content body mensage of the response.</returns>
        public string PutHttpWebRequest(string pathUrl, string contentType, int statusCodeHttp, string[] expectedValue, string[,] headers, string json)
        {
            HttpWebRequest webrequest = null;
            try
            {
                if (pathUrl != null)
                {
                    strServer = baseUri + "/" + ReplaceValueForUrlEncode(pathUrl);
                }
                else
                {
                    strServer = baseUri;
                }
                webrequest = (HttpWebRequest)WebRequest.Create(strServer);

                if (headers != null)
                {
                    for (int i = 0; i <= headers.GetUpperBound(0); i++)
                    {
                        webrequest.Headers.Add(headers[i, 0], headers[i, 1]);
                    }

                }

                webrequest.Method = "PUT";

                if (contentType != null)
                {
                    webrequest.ContentType = "application/" + contentType;
                }


                using (var streamWriter = new StreamWriter(webrequest.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                HttpWebResponse resposta = (HttpWebResponse)webrequest.GetResponse();
                Stream streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                objResponse = reader.ReadToEnd();

                if ((int)resposta.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PutHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)resposta.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("\n Resposta gerada com sucesso \n O Valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso \n O Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }
                    }
                }
                else
                {
                    Assert.Fail("Metodo PutHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)resposta.StatusCode + " \n log error:" + objResponse);
                }

                ReportStep("Response body: \n \n" + objResponse);
                streamDados.Close();
                resposta.Close();
            }
            catch (WebException wex)
            {

                var errorResponse = (HttpWebResponse)wex.Response;

                var reader = new StreamReader(errorResponse.GetResponseStream());

                string objResponse = reader.ReadToEnd();

                if ((int)errorResponse.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PutHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)errorResponse.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("Resposta gerada com sucesso.\n O valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso, porém o Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }

                    }
                }
                else
                {
                    Assert.Fail("Metodo PutHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)errorResponse.StatusCode + " \n log error:" + objResponse);
                }

            }
            catch (Exception ex)
            {
                Assert.Fail("Metodo PutHttpWebRequest \n Erro ao Processar a requisição para o WebService. Log: " + ex.ToString());
            }

            return objResponse;
        }

        #endregion

        #region Metodos PATCH

        /// <summary>
        /// Post Web Request and send body json and validate status http and bory message 
        /// </summary>
        /// <param name="pathUrl"> addres to complement address of the webservice, for exampla: "api/fale-conosco?tipoUsuario=Não Cliente&filtro.localidade=SP&filtro.assunto=duvida" </param>
        /// <param name="contentType"> kind of the content-type for exampla: json or xml or text</param>
        /// <param name="statusCodeHttp"> kind of the Response Code http for example: 200, 201, 302. if greatest than 400 is consider WebException </param>
        /// <param name="expectedValue"> value expected in body menssage</param>
        /// <param name="json"> value with json in format string </param>
        /// <returns>The <see cref="objResponse"/> return value of the kind string content body mensage of the response.</returns>
        public string PatchHttpWebRequest(string pathUrl, string contentType, int statusCodeHttp, string[] expectedValue, string[,] headers, string json)
        {
            HttpWebRequest webrequest = null;
            try
            {
                if (pathUrl != null)
                {
                    strServer = baseUri + "/" + ReplaceValueForUrlEncode(pathUrl);
                }
                else
                {
                    strServer = baseUri;
                }
                webrequest = (HttpWebRequest)WebRequest.Create(strServer);

                if(headers != null)
                {
                    for (int i = 0; i <= headers.GetUpperBound(0); i++)
                    {
                        webrequest.Headers.Add(headers[i, 0], headers[i, 1]);
                    }

                }

                webrequest.Method = "PATCH";

                if (contentType != null)
                {
                    webrequest.ContentType = "application/" + contentType;
                }

                if(json != null)
                {
                    using (var streamWriter = new StreamWriter(webrequest.GetRequestStream()))
                    {
                        streamWriter.Write(json);
                        streamWriter.Flush();
                        streamWriter.Close();
                    }
                }

                HttpWebResponse resposta = (HttpWebResponse)webrequest.GetResponse();
                Stream streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                objResponse = reader.ReadToEnd();

                if ((int)resposta.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PatchHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)resposta.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("\n Resposta gerada com sucesso \n O Valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso \n O Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }
                    }
                }
                else
                {
                    Assert.Fail("Metodo PatchHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)resposta.StatusCode + " \n log error:" + objResponse);
                }

                ReportStep("Response body: \n \n" + objResponse);
                streamDados.Close();
                resposta.Close();
            }
            catch (WebException wex)
            {

                var errorResponse = (HttpWebResponse)wex.Response;

                var reader = new StreamReader(errorResponse.GetResponseStream());

                string objResponse = reader.ReadToEnd();

                if ((int)errorResponse.StatusCode == statusCodeHttp)
                {
                    ReportStep("Metodo PatchHttpWebRequest<  \n \n Request: " + strServer + " \n Status Code: " + (int)errorResponse.StatusCode);

                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (objResponse.Contains(value.ToString()))
                            {
                                ReportStep("Resposta gerada com sucesso.\n O valor '" + value + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("\n Resposta gerada com sucesso, porém o Valor '" + value + "' NÃO foi encontrado!");
                            }
                        }

                    }
                }
                else
                {
                    Assert.Fail("Metodo PatchHttpWebRequest: 'FALHOU' \n  Status esperado: " + statusCodeHttp + " \n Resultado Atual: " + (int)errorResponse.StatusCode + " \n log error:" + objResponse);
                }

            }
            catch (Exception ex)
            {
                Assert.Fail("Metodo PatchHttpWebRequest \n Erro ao Processar a requisição para o WebService. Log: " + ex.ToString());
            }

            return objResponse;
        }

       
        #endregion
    }
}
