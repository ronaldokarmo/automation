﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OGS.Framework.Setup;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;

namespace OGS.Framework.Utility
{
    public class DataBase : ConfigReports
    {
        #region atributos

        OracleConnection conexao;
        OracleDataReader reader;
        private string host { get; set; }
        private string port { get; set; }
        private string serviceName { get; set; }
        private string user { get; set; }
        private string passWord { get; set; }

        private int numberOfRecords;

        #endregion

        #region Metodos
        public DataBase(string _host, string _port, string _serviceName, string _user, string _passWord)
        {
            host = _host;
            port = _port;
            serviceName = _serviceName;
            user = _user;
            passWord = _passWord;
        }

        public OracleConnection ConnectDataBase()
        {
            try
            {
                conexao = new
                OracleConnection("Data Source=" +
                "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)" +
                "(HOST=" + host + ")(PORT=" + port + "))" +
                "(CONNECT_DATA=(SERVER=DEDICATED)" +
                "(SERVICE_NAME=" + serviceName + ")));User ID=" + user + ";Password=" + passWord + ";");

                conexao.Open();
                ReportStep(("Aberto a conexão com o banco: \n host: " + host + " Port: " + port + " Service Name: " + serviceName));
            }
            catch (Exception e)
            {
                Assert.Fail("Metodo ConnectarDataBase falhou ao tentar se conectar a base de dados, log: " + e.ToString());
            }
            return conexao;
        }

        public void CloseConnection()
        {

            try
            {
                conexao.Close();
                ReportStep("Fechada a conexão com o banco");
            }
            catch (Exception e)
            {
                Assert.Fail("Metodo ConnectarDataBase falhou ao tentar fechar conexão com a base de dados, log: " + e.ToString());
            }

        }

        public string SelectCommand(string querySql, string[] expectedValue)
        {

            string reponse = null;

            try
            {
                OracleCommand comm = new OracleCommand();

                comm.Connection = conexao;
                comm.CommandText = querySql;
                comm.CommandTimeout = 72000;
                comm.ExecuteNonQuery();

                reader = comm.ExecuteReader();

                // Exibindo os registros
                while (reader.Read())
                {

                    for (int i = 0; i < reader.FieldCount; i++)
                    {

                        if (reponse == null)
                        {
                            reponse = reader[i].ToString();
                        }
                        else
                        {
                            reponse = reponse + ";" + reader[i].ToString();
                        }
                    }

                }

                if (reponse != null)
                {
                    if (expectedValue != null)
                    {
                        foreach (string value in expectedValue)
                        {
                            if (reponse.Contains(value.ToString()))
                            {
                                ReportStep("Query executada: " + querySql + "\n O valor '" + expectedValue + "' foi encontrado!");
                            }
                            else
                            {
                                Assert.Fail("Query executada: " + querySql + "\n O valor '" + expectedValue + "' NÃO foi encontrado!");
                            }
                        }
                    }

                }
                else
                {
                    Assert.Fail("Query executada: " + querySql + "\n Não retornou dados!");
                }

                ReportStep("Resultado da query: " + reponse);

                // Fecha o datareader
                if (reader != null)
                {
                    reader.Close();
                }
            }
            catch (OracleException e)
            {
                Assert.Fail("Metodo SelectCommand falhou ao tentar executar a query: " + querySql + " \n\n Log: " + e.ToString());
            }

            return reponse;
        }

        public int UpdateCommand(string querySql)
        {
            try
            {
                OracleCommand comm = new OracleCommand();

                comm.Connection = conexao;
                comm.CommandText = querySql;
                comm.CommandTimeout = 72000;
                numberOfRecords = comm.ExecuteNonQuery();

                if (numberOfRecords >= 1)
                {
                    ReportStep("Query executada: " + querySql + " o registro foi atualizado.");
                }
                else
                {
                    Assert.Fail("Query executada: " + querySql + ", porém o registro NÃO foi atualizado.");
                }
            }
            catch (OracleException e)
            {
                Assert.Fail("Metodo UpdateCommand falhou ao tentar executar a query: " + querySql + " \n\n Log: " + e.ToString());

            }

            return numberOfRecords;

        }

        public int DeleteCommand(string querySql)
        {

            try
            {
                OracleCommand comm = new OracleCommand();

                comm.Connection = conexao;
                comm.CommandText = querySql;
                comm.CommandTimeout = 72000;
                numberOfRecords = comm.ExecuteNonQuery();

                if (numberOfRecords >= 1)
                {
                    ReportStep("Query executada: " + querySql + " O registro foi deletado.");
                }
                else
                {
                    Assert.Fail("Query executada: " + querySql + " O registro não foi deletado.");
                }
            }
            catch (OracleException e)
            {
                Assert.Fail("Metodo DeleteCommand falhou ao tentar executar a query: " + querySql + " \n\n Log: " + e.ToString());
            }

            return numberOfRecords;
        }

        public int InsertCommand(string querySql)
        {

            try
            {
                OracleCommand comm = new OracleCommand();

                comm.Connection = conexao;
                comm.CommandText = querySql;
                comm.CommandTimeout = 72000;
                numberOfRecords = comm.ExecuteNonQuery();

                if (numberOfRecords >= 1)
                {
                    ReportStep("Query executada: " + querySql + " O registro foi inserido.");
                }
                else
                {
                    Assert.Fail("Query executada: " + querySql + " O registro não foi inserido.");
                }

            }
            catch (OracleException e)
            {
                Assert.Fail("Metodo InsertCommand falhou ao tentar executar a query: " + querySql + " \n\n Log: " + e.ToString());

            }

            return numberOfRecords;
        }

        public void ExecuteProcedure(string nameProcedure)
        {

            try
            {
                OracleCommand comm = new OracleCommand(nameProcedure, conexao);
                comm.CommandType = CommandType.StoredProcedure;
                comm.ExecuteNonQuery();
                ReportStep("procedure executada: " + nameProcedure + " com sucesso.");

            }
            catch (OracleException e)
            {
                Assert.Fail("Metodo ExecuteProcedure falhou ao tentar executar a procedure: " + nameProcedure + " \n\n Log: " + e.ToString());

            }

        }
        #endregion 
    }
}
