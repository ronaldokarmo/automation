﻿using OGS.Framework.Setup;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OGS.Framework.Utility
{
    class GetData : ConfigReports
    {



    }
}
