﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OGS.Framework.Model.Obejct.Repository;
using OGS.Framework.Setup;
using System.Threading;
using OGS.Framework.Controller.Actions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OGS.Framework.Utility
{
    public class Verification : ConfigReports
    {
 
        public static void HighlightElement(IWebDriver driver, IWebElement element)
        {
            try
            {
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                js.ExecuteScript("arguments[0].style.border='2px dashed red'", element);
                js.ExecuteScript("arguments[0].style.border='1,5'", element);
                Wait(1);
                js.ExecuteScript("arguments[0].style.border=''", element);
                js.ExecuteScript("arguments[0].style.border=''", element);
            }
            catch (Exception e)
            {
                Console.WriteLine("Elemento não visível para HighLight: " + e);
            }
        }

        public static void Wait(int seconds)
        {
            Thread.Sleep(seconds * 1000);
        }

        /// <summary>
        /// An expectation for checking that an element is present on the DOM of a
        /// page. This does not necessarily mean that the element is visible or clickable.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="seconds"> wait for a determined time </param>
        public static void VerifyElementExists(IWebDriver driver,string locatorType, string locator, int seconds)
        {
            IWebElement element = ElementActions.GetExistingElement(driver, locatorType, locator, seconds);
            HighlightElement(driver, element);
            ReportStep(driver, $"O elemento web [{locator}] foi identificado com sucesso.");
        }

        /// <summary>
        /// An expectation for checking an element is visible and can be clicked
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="seconds"> wait for a determined time </param>
        public static void VerifyElementIsClickable(IWebDriver driver, string locatorType, string locator, int seconds)
        {
            IWebElement element = ElementActions.GetClickableElement(driver, locatorType, locator, seconds);
            HighlightElement(driver,element);
            ReportStep(driver, $"O elemento web [{locator}] é clicável.");
        }

        /// <summary>
        /// An expectation for checking if the given element is in correct state.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="isSelected"> represent the value of kind boolean, true element is selected, false element is not selected</param>
        /// <param name="seconds"> wait for a determined time </param>
        public static void VerifyElementSelectionStateIs(IWebDriver driver, string locatorType, string locator, bool isSelected, int seconds)
        {
            IWebElement element = ElementActions.GetClickableElement(driver, locatorType, locator, seconds);
            if (isSelected)
            {
                Assert.IsTrue(element.Selected, $"O elemento web [{locator}] deveria estar selecionado.");
                ReportStep(driver, $"O elemento web [{locator}] está selecionado.");
            }
            else
            {
                Assert.IsFalse(element.Selected, $"O elemento web [{locator}] não deveria estar selecionado.");
                ReportStep(driver, $"O elemento web [{locator}] não está selecionado.");
            }
        }

        /// <summary>
        /// An expectation for checking if the given text is present in the specified elements.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="expectedText"> text expected to be in Element Text property</param>
        /// <param name="seconds"> wait for a determined time </param>
        public static void VerifyElementTextContains(IWebDriver driver,string locatorType, string locator, int seconds, string expectedText)
        {
            IWebElement element = ElementActions.GetClickableElement(driver, locatorType, locator, seconds);
            Assert.IsTrue(element.Text.Contains(expectedText));
            ReportStep(driver, $"O elemento web [{locator}] contém o texto [{expectedText}].");
        }

        /// <summary>
        /// An expectation for checking if the given text is present in the specified elements.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="expectedText"> exact text expected in Element Text property</param>
        /// <param name="seconds"> wait for a determined time </param>
        public static void VerifyElementTextMatches(IWebDriver driver,string locatorType, string locator, int seconds, string expectedText)
        {
            IWebElement element = ElementActions.GetClickableElement(driver, locatorType, locator, seconds);
            Assert.AreEqual(expectedText, element.Text);
            ReportStep(driver, $"O elemento web [{locator}] apresenta o texto [{expectedText}].");
        }

        /// <summary>
        /// An expectation for checking if the given text is present in the specified elements value attribute.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="seconds"> wait for a determined time </param>
        /// <param name="attribute"> represent the attribute from the Element to be verified</param>
        /// <param name="expectedText"> text expected to be in Element attribute</param>
        public static void VerifyElementAttributeContains(IWebDriver driver, string locatorType, string locator, int seconds, string attribute, string expectedText)
        {
            IWebElement element = ElementActions.GetClickableElement(driver, locatorType, locator, seconds);
            Assert.IsTrue(element.GetAttribute(attribute).Contains(expectedText));
            ReportStep(driver, $"O elemento web [{locator}] apresenta o texto [{expectedText}].");
        }

        /// <summary>
        /// An expectation for checking if the given text is present in the specified elements value attribute.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="seconds"> wait for a determined time </param>
        /// <param name="attribute"> represent the attribute from the Element to be verified</param>
        /// <param name="expectedText"> exact text expected to be in Element attribute</param>
        public static void VerifyElementAttributeMatches(IWebDriver driver, string locatorType, string locator, int seconds, string attribute, string expectedText)
        {
            IWebElement element = ElementActions.GetClickableElement(driver, locatorType, locator, seconds);
            Assert.AreEqual(expectedText, element.GetAttribute(attribute));
            ReportStep(driver, $"Atributo [{attribute}] do elemento web [{locator}] apresenta o texto [{expectedText}].");
        }

        /// <summary>
        /// An expectation for checking if the given element is in correct state.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="isVisible"> represent the value of kind boolean, true element is selected, false element is not selected</param>
        /// <param name="seconds"> wait for a determined time </param>
        public static void VerifyElementVisibilityStateIs(IWebDriver driver,string locatorType, string locator, bool isVisible, int seconds)
        {
            IWebElement element = ElementActions.GetExistingElement(driver,locatorType, locator, seconds);
            if (isVisible)
            {
                Assert.IsTrue(element.Displayed, string.Format($"Elemento [{locator}] deveria ser visível na tela."));
                ReportStep(driver, $"Elemento [{locator}] é visível na tela.");
            }
            else
            {
                Assert.IsFalse(element.Displayed, string.Format($"Elemento [{locator}] não deveria ser visível na tela.")); ;
                ReportStep(driver, $"Elemento [{locator}] não é visível na tela.");
            }
        }

        /// <summary>
        /// An expectation for checking if the given element is in correct state.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="locator"> represent the value of the locatorType</param>
        /// <param name="seconds"> wait for a determined time </param>
        public static void VerifyElementDoesNotExist(IWebDriver driver, string locatorType, string locator, int seconds)
        {
            Assert.IsTrue(driver.FindElements(ModelObject.ElementLocator(locatorType, locator)).Count < 1, "Elemento " + locator + " não deveria existir na tela.");
            ReportStep(driver, $"Elemento [{locator}] não existe na tela.");
        }

        /// <summary>
        /// An expectation for checking whether the given frame is available to switch
        /// to. If the frame is available it switches the given driver to the
        /// specified frame.
        /// </summary>
        /// <param name="locatorType"> kind of By</param>
        /// <param name="value"> represent the value of the locatorType</param>
        /// <param name="seconds"> wait for a determined time </param>
        /// <returns><see cref="IWebDriver"/></returns>
        public static IWebDriver WaitFrameToBeAvailableAndSwitchToIt(IWebDriver driver, string locatorType, string value, int seconds)
        {
            IWebDriver drive = new WebDriverWait(driver, TimeSpan.FromSeconds(seconds))
                .Until(ExpectedConditions.FrameToBeAvailableAndSwitchToIt(ModelObject.ElementLocator(locatorType, value)));
            ReportStep(drive, $"O elemento web [{value}] foi identificado com sucesso .");
            return drive;
        }
    }
}
