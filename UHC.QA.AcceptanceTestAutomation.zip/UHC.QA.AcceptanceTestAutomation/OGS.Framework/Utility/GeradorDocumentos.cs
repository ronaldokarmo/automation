﻿using System;

namespace Framework.Utilities
{
    public class CNPJgenerator
    {
        /// <summary>
        /// O metodo retorna um valor com um CNPJ ficticio valido para testes, retorna um valor do tipo string
        /// </summary>
        /// <returns>Retorna um valor do tipo string com 14 colunas</returns>
        public static String GeradorCNPJ()
        {
            int digit1 = 0, digit2 = 0, remainder = 0;
            string nDigResult;
            string numbersSum;
            string numberGenerated;

            ///Gerando numeros aleatórios
            Random rnd = new Random();
            int n1 = rnd.Next(10);
            int n2 = rnd.Next(10);
            int n3 = rnd.Next(10);
            int n4 = rnd.Next(10);
            int n5 = rnd.Next(10);
            int n6 = rnd.Next(10);
            int n7 = rnd.Next(10);
            int n8 = rnd.Next(10);
            int n9 = rnd.Next(10);
            int n10 = rnd.Next(10);
            int n11 = rnd.Next(10);
            int n12 = rnd.Next(10);

            int sum = n12 * 2 + n11 * 3 + n10 * 4 + n9 * 5 + n8 * 6 + n7 * 7 + n6 * 8 + n5 * 9 + n4 * 2 + n3 * 3 + n2 * 4 + n1 * 5;
            int value = (sum / 11) * 11;
            digit1 = sum - value;

            ///Primeiro resto da divisão por 11.
            remainder = (digit1 % 11);
            if (digit1 < 2)
                digit1 = 0;
            else
            {
                digit1 = 11 - remainder;
            }

            int sum2 = digit1 * 2 + n12 * 3 + n11 * 4 + n10 * 5 + n9 * 6 + n8 * 7 + n7 * 8 + n6 * 9 + n5 * 2 + n4 * 3 + n3 * 4 + n2 * 5 + n1 * 6;
            int value2 = (sum2 / 11) * 11;
            digit2 = sum2 - value2;

            ///Primeiro resto da divisão por 11.
            remainder = (digit2 % 11);
            if (digit2 < 2)
                digit2 = 0;
            else
            {
                digit2 = 11 - remainder;
            }

            ///Concatenando os numeros
            numbersSum = string.Format($"{n1}{n2}{n3}{n4}{n5}{n6}{n7}{n8}{n9}{n10}{n11}{n12}");
            ///Concatenando o primeiro resto com o segundo.
            nDigResult = string.Format($"{digit1}{digit2}");
            numberGenerated = numbersSum + nDigResult;

            return numberGenerated;
        }
        /// <summary>
        /// O metodo retorna um valor com um CPF ficticio valido para testes, retorna um valor do tipo string
        /// </summary>
        /// <returns>Retorna um valor do tipo string com 11 colunas</returns>
        public static String GeradorCPF()
        {
            int sum = 0, remainder = 0;
            int[] multiplier1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplier2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            Random rnd = RandomNumber();
            string seednumber = rnd.Next(100000000, 999999999).ToString();

            for (int i = 0; i < 9; i++)
                sum += int.Parse(seednumber[i].ToString()) * multiplier1[i];

            remainder = sum % 11;
            if (remainder < 2)
                remainder = 0;
            else
            {
                remainder = 11 - remainder;
            }

            seednumber = seednumber + remainder;
            sum = 0;

            for (int i = 0; i < 10; i++)
                sum += int.Parse(seednumber[i].ToString()) * multiplier2[i];

            remainder = sum % 11;

            if (remainder < 2)
                remainder = 0;
            else
            {
                remainder = 11 - remainder;
            }

            seednumber = seednumber + remainder;
            return seednumber;
        }

        /// <summary>
        /// O metodo retorna um valor aleatório de CPF/CNPJ
        /// </summary>
        /// <returns>Retorna um valor do tipo string com 11 ou 14 colunas</returns>
        protected static Random RandomNumber()
        {
            return new Random();
        }
    }
}
