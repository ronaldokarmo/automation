﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OGS.Framework.Model.Obejct.Repository;
using OGS.Framework.Setup;
using OGS.Framework.Utility;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OGS.Framework.Controller.Actions
{
    public class ElementActions : ConfigReports
    {
        #region Actions
        /// <summary>
        /// Returns an existing element from the screen
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="seconds"> Waits for the defined time set as parameter</param>
        public static IWebElement GetExistingElement(IWebDriver driver, string locatorType, string locator, int seconds)
        {
            IWebElement element = new WebDriverWait(driver, TimeSpan.FromSeconds(seconds))
            .Until(ExpectedConditions.ElementExists(ModelObject.ElementLocator(locatorType, locator)));
            return element;
        }

        /// <summary>
        /// Returns a clickable element from the screen
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="seconds"> Waits for the defined time set as parameter</param>
        public static IWebElement GetClickableElement(IWebDriver driver, string locatorType, string locator, int seconds)
        {
            IWebElement element = new WebDriverWait(driver, TimeSpan.FromSeconds(seconds))
            .Until(ExpectedConditions.ElementToBeClickable(ModelObject.ElementLocator(locatorType, locator)));
            return element;
        }

        /// <summary>
        /// Clear a Web Element Text Field
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="seconds"> Waits for the defined time set as parameter</param>
        public static void ClearField(IWebDriver driver, string locatorType, string locator, int seconds)
        {
            //if the object is not enabled or visibled, this line finalizes the test, but if the object exists the method returns a Web Element object
            IWebElement element = GetClickableElement(driver, locatorType, locator, seconds);
            //Highlights the field requested
            Verification.HighlightElement(driver, element);
            element.Clear();
        }

        /// <summary>
        /// Inserts text in a Web Element Text Field
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="seconds"> Waits for the defined time set as parameter</param>
        public static void SetText(IWebDriver driver, string locatorType, string locator, string text, int seconds)
        {
            //if the object is not enabled or visibled, this line finalizes the test, but if the object exists the method returns a Web Element object
            IWebElement element = GetClickableElement(driver,locatorType, locator, seconds);
            //Highlights the field requested
            Verification.HighlightElement(driver,element);
            element.Click(); element.Clear(); element.SendKeys(text);
        }

        /// <summary>
        /// Clicks in the web element
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void ClickOnElement(IWebDriver driver,string locatorType, string locator, int seconds)
        {
            //if the object is not enabled or visibled, this line finalizes the test, but if the object exists the method returns a Web Element object
            IWebElement element = GetClickableElement(driver,locatorType, locator, seconds);
            //Highlights the field requested
            Verification.HighlightElement(driver, element);
            //Clicks at the element requested
            element.Click();
        }

        /// <summary>
        /// Clicks in the web element
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void ClickOnElementIfDisplayed(IWebDriver driver, string locatorType, string locator, int seconds)
        {
            if (driver.FindElements(ModelObject.ElementLocator(locatorType, locator)).Count >= 1)
            {
                IWebElement element = GetClickableElement(driver, locatorType, locator, seconds);
                Verification.HighlightElement(driver, element);
                element.Click();
            }
        }

        /// <summary>
        /// Select item in web element ComboBox by text
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="optionText"> Represents the text of the option to select</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void SelectComboOptionByText(IWebDriver driver,string locatorType, string locator, string optionText, int seconds)
        {
            //if the object is not enabled or visibled, this line finalizes the test, but if the object exists the method returns a Web Element object
            IWebElement element = GetClickableElement(driver, locatorType, locator, seconds);
            //Highlights the field requested
            SelectElement SelectCombo = new SelectElement(element);
            //Selects an item at the ComboBox referred
            SelectCombo.SelectByText(optionText);
            //Clicks at the element requested
        }

        /// <summary>
        /// Select item in web element ComboBox by index
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="index"> Represents the index of the option to select</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void SelectComboOptionByIndex(IWebDriver driver, string locatorType, string locator, int index, int seconds)
        {
            //if the object is not enabled or visibled, this line finalizes the test, but if the object exists the method returns a Web Element object
            IWebElement element = GetClickableElement(driver, locatorType, locator, seconds);
            //Highlights the field requested
            SelectElement SelectCombo = new SelectElement(element);
            //Selects an item at the ComboBox referred
            SelectCombo.SelectByIndex(index);
            //Clicks at the element requested
        }

        /// <summary>
        /// Select item in web element CheckBox by index
        /// </summary>
        /// <param name="locator"> Represents the name of the checkbox element. Provides a list of available options.</param>
        /// <param name="index"> Represents the index of the option to select</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void SelectCheckboxOptionByIndex(IWebDriver driver, string locatorType, string locator, int index, int seconds)
        {
            Verification.VerifyElementIsClickable(driver, locatorType, locator, seconds);
            IList<IWebElement> checkbox = driver.FindElements(ModelObject.ElementLocator(locatorType, locator));
            if (!checkbox.ElementAt(index).Selected)
            {
                checkbox.ElementAt(index).Click();
            }
        }

        /// <summary>
        /// Select item in web element CheckBox by value
        /// </summary>
        /// <param name="locator"> Represents the name of the checkbox element. Provides a list of available options.</param>
        /// <param name="optionValue"> Represents the value of the option to select</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void SelectCheckboxOptionByValue(IWebDriver driver, string locatorType, string locator, string optionValue, int seconds)
        {
            Verification.VerifyElementIsClickable(driver, locatorType, locator, seconds);
            IList<IWebElement> checkbox = driver.FindElements(ModelObject.ElementLocator(locatorType, locator));
            int checkboxSize = checkbox.Count;
            for (int i = 0; i < checkboxSize; i++)
            {
                string value = checkbox.ElementAt(i).GetAttribute("value");
                if (value.Equals(optionValue))
                {
                    if (!checkbox.ElementAt(i).Selected)
                    {
                        checkbox.ElementAt(i).Click();
                    }
                    break;
                }
            }
        }

        /// <summary>
        /// Select item in web element Radio Button by value
        /// </summary>
        /// <param name="locator"> Represents the name of the radio  button collection element. Provides a list of available options.</param>
        /// <param name="optionValue"> Represents the value of the option to select</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void SelectRadioOptionByValue(IWebDriver driver, string locatorType, string locator, string optionValue, int seconds)
        {
            Verification.VerifyElementIsClickable(driver, locatorType, locator, seconds);
            IList<IWebElement> radioButton = driver.FindElements(ModelObject.ElementLocator(locatorType, locator));
            int checkboxSize = radioButton.Count;
            for (int i = 0; i < checkboxSize; i++)
            {
                string value = radioButton.ElementAt(i).GetAttribute("value");
                if (value.Equals(optionValue))
                {
                    if (!radioButton.ElementAt(i).Selected)
                    {
                        radioButton.ElementAt(i).Click();
                    }
                    break;
                }
            }
        }

        /// <summary>
        /// Select item in web element Radio Button by index
        /// </summary>
        /// <param name="locator"> Represents the name of the checkbox element. Provides a list of available options.</param>
        /// <param name="index"> Represents the index of the option to select</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void SelectRadioOptionByIndex(IWebDriver driver, string locatorType, string locator, int index, int seconds)
        {
            Verification.VerifyElementIsClickable(driver,locatorType, locator, seconds);
            IList<IWebElement> radioButton = driver.FindElements(ModelObject.ElementLocator(locatorType, locator));
            if (!radioButton.ElementAt(index).Selected)
            {
                radioButton.ElementAt(index).Click();
            }
        }

        /// <summary>
        /// Drags and Drops components on screen
        /// </summary>
        /// <param name="locatorTypeFrom"> Type of "By" to From</param>
        /// <param name="locatorFrom"> Represents the locator of the "From" locatorType</param>
        /// <param name="locatorTypeTo"> Type of "By" to "To"</param>
        /// <param name="locatorTo"> Represents the locator of the "To" locatorType</param>
        /// <param name="seconds"> Waits for the defined time set as parameter </param>
        public static void DragAndDrop(IWebDriver driver, string locatorTypeFrom, string locatorFrom, string locatorTypeTo, string locatorTo, int seconds)
        {
            //if the object is not enabled or visibled, this line finalizes the test, but if the object exists the method returns a Web Element object
            IWebElement from = GetClickableElement(driver, locatorTypeFrom, locatorFrom, seconds);
            //if the object is not enabled or visibled, this line finalizes the test, but if the object exists the method returns a Web Element object
            IWebElement to = GetClickableElement(driver, locatorTypeTo, locatorTo, seconds);
            //Drags and drops from one place to other
            actions.DragAndDrop(from, to).Build().Perform();
        }

        /// <summary>
        /// Returns the boolean state of an element existence
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        public static bool ProceedIfElementExists(IWebDriver driver, string locatorType, string locator)
        {
            bool doesElementExist = false;
            IReadOnlyCollection<IWebElement> elements = driver.FindElements(ModelObject.ElementLocator(locatorType, locator));
            if(elements.Count > 0)
            {
                doesElementExist = true;
            }
            return doesElementExist;
        }

        /// <summary>
        /// Switches from screen to a Frame
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="seconds"> maximum time to wait for the condition</param>
        public static void SwitchToFrame(IWebDriver driver, string locatorType, string locator, int seconds)
        {
            Verification.Wait(2);
            //If the object is not enabled or visibled, this line finalizes the test, but if the object exists the method returns a Web Element object
            IWebElement iFrame = GetClickableElement(driver, locatorType, locator, seconds);
            //Switches from the current screen to the frame requested
            driver.SwitchTo().Frame(iFrame);
        }

        /// <summary>
        /// Switches back from the frame to the screen
        /// </summary>
        public static void SwitchToPreviousFrame(IWebDriver driver)
        {
            //Switches from the current frame to the previous screen
            driver.SwitchTo().Window(driver.WindowHandles.First());
            Console.WriteLine(string.Format($"Mudança para o frame principal da aplicação realizado com sucesso"));
            //test.Log(logstatus, string.Format($"Mudança para o frame principal da aplicação realizado com sucesso."), MediaEntityBuilder.CreateScreenCaptureFromPath(ScreenShot()).Build());
        }


        public static string GetTextFromElement(IWebDriver driver,string locatorType, string locator, int seconds)
        {
            string textExtracted = null;
            IWebElement element = GetClickableElement(driver, locatorType, locator, seconds);
            Verification.HighlightElement(driver, element);

            if (element.Text != null)
            {
                textExtracted = "";
                textExtracted = element.Text.TrimEnd();
            }
            else
            {
                Assert.Fail(string.Format($"Falha ao capturar o valor!"));
            }
            return textExtracted;
        }


        /// <summary>
        /// Returns the text from the Web Element
        /// </summary>
        /// <param name="locatorType"> Type of "By"</param>
        /// <param name="locator"> Represents the locator of the locatorType</param>
        /// <param name="attribute"> Represents the name of the attribute that will be captured</param>
        public static string GetAttributeValueFromElement(IWebDriver driver, string locatorType, string locator, string attribute, int seconds)
        {
            IWebElement element = GetClickableElement(driver, locatorType, locator, seconds);
            return element.GetAttribute(attribute).TrimEnd();
        }

        /// <summary>
        /// Simulates a key pressed from the keyboard
        /// </summary>
        /// <param name="key"> Parameter that sends the key to be pressed </param>
        public static void PressKeyFromKeyboard(string key)
        {
            SendKeys.SendWait(key);
        }

        #endregion

    }

}

